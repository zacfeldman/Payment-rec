import com.egis.AllocationOptions
import com.egis.DocumentModel
import com.egis.data.party.Group
import com.egis.data.party.User
import com.egis.kernel.Kernel
import com.egis.kernel.db.DbManager
import com.egis.allocation.RotationalDistributionEngine
import com.egis.utils.Is

DocumentModel doc = doc
DocumentModel paymentAuth = doc.session.getDocument("SELECT * FROM 'Sanlam Glacier/Finance/Payment Authorisation' WHERE recursive = true AND formNo = '${doc.formNo}'")

if (Is.empty(paymentAuth)) {
    return
}

doc.can_reassign = 'true'

DbManager db = Kernel.get(DbManager.class)
RotationalDistributionEngine distributionEngine = Kernel.get(RotationalDistributionEngine.class)
User party = db.ensureConnected(distributionEngine.getNextUserFromGroup(db.ensureConnected(Kernel.get(User.class)), doc.getNode().node, db.resolve(Group.class, 'Accountant Group')))

paymentAuth.parties().add(party, new AllocationOptions(instruction: "Please confirm Cost Centre Head Assignment on Cost Centre ${doc.cost_centre} - ${doc.co_code}"))