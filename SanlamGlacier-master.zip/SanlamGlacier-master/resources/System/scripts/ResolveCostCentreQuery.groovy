import com.egis.AllocationOptions
import com.egis.DocumentModel
import com.egis.utils.Is

DocumentModel doc = doc

DocumentModel paymentAuth = doc.session.getDocument("SELECT * FROM 'Sanlam Glacier/Finance/Payment Authorisation' WHERE recursive = true AND formNo = '${doc.formNo}'")

if (Is.empty(paymentAuth)) {
    return
}

paymentAuth.parties().remove(paymentAuth.createdBy)

paymentAuth.applyRule("runScript", [path: 'System/scripts/ValidateTotals.groovy'])

paymentAuth.parties().add(doc.approver, new AllocationOptions(instruction: "Query Resolution on Cost Centre ${doc.cost_centre} - ${doc.co_code}: ${doc.query_resolution}"))
paymentAuth.audits().add('Queried Resolved by Requestor', doc.query_resolution ?: '')