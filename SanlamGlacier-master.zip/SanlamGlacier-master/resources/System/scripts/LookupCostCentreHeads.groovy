import com.egis.DocumentModel
import com.egis.data.party.User
import com.egis.kernel.Kernel
import com.egis.kernel.db.DbManager
import com.egis.utils.Is
import com.egis.utils.ValidationException

DocumentModel doc = doc

def costCentreHeads = []
def missingHeads = []

doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Tables' " +
        "WHERE formNo = '${doc.formNo}'").each { DocumentModel costCentre ->

    BigDecimal total = new BigDecimal((costCentre.debit_total ?: '0').replaceAll(',', ''))

    def debitApprover

    doc.session.query("SELECT * FROM 'Lookup Matrix/Department Details' " +
            "WHERE Cost_Centre = '${costCentre.Cost_Centre}' AND company = '${costCentre.co_code}'").each { DocumentModel approver ->

        BigDecimal min = new BigDecimal(approver.threshold_min ?: '0')
        BigDecimal max = new BigDecimal(approver.threshold_max ?: '0')

        if (total >= min && total < max) {

            if (Is.empty(debitApprover)) {
                debitApprover = approver
            }

            if ('true'.equalsIgnoreCase(approver.default)) {
                debitApprover = approver
            }
        }
    }

    if (Is.empty(debitApprover)) {
        missingHeads.add("No Cost Centre Head ${costCentre.Cost_Centre}-${costCentre.co_code} Defined to Allocate for Approval - Contact Administrator")
        doc.missing_heads = 'true'
    } else {

        DbManager db = Kernel.get(DbManager.class)
        if (Is.empty(db.resolve(User.class, debitApprover.approver))) {
            throw new ValidationException("No User found for ${debitApprover.approver}")
        }

        costCentreHeads << debitApprover.approver
        costCentre.approver = debitApprover.approver
        costCentre.cost_centre_head_approved = 'false'
    }

    costCentre.allocate('Cost Centre Workflow')
}

if (!Is.empty(missingHeads)) {
    throw new ValidationException(missingHeads.join("\n"))
}

if (Is.empty(costCentreHeads)) {
    throw new ValidationException("No Cost Centre Heads to Allocate to")
}

doc.cost_centre_heads = String.join(',', costCentreHeads)