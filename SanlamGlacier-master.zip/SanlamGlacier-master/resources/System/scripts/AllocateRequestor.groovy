import com.egis.AllocationOptions
import com.egis.DocumentModel
import com.egis.utils.Is

DocumentModel doc = doc

DocumentModel paymentAuth = doc.session.getDocument("SELECT * FROM 'Sanlam Glacier/Finance/Payment Authorisation' WHERE recursive = true AND formNo = '${doc.formNo}'")

if (Is.empty(paymentAuth)) {
    return
}

paymentAuth.parties().remove(doc.approver)

paymentAuth.parties().add(paymentAuth.createdBy, new AllocationOptions(instruction: "Please action Query on Cost Centre ${doc.cost_centre} - ${doc.co_code}: ${doc.query_reason}"))
paymentAuth.audits().add('Queried Back to Requestor', doc.query_reason ?: '')