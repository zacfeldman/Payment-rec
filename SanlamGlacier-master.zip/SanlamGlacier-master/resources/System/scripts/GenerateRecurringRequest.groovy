import com.egis.DocumentDTO
import com.egis.DocumentModel
import com.egis.Repository
import com.egis.Session
import com.egis.kernel.Kernel
import com.egis.utils.Handler
import com.egis.utils.Is

DocumentModel doc = doc

if (Is.empty(doc.contract_period)) {
    return
}

def contractPeriod = Integer.parseInt(doc.contract_period)
def copied = Integer.parseInt(doc.recurring_copies ?: '0')


if (contractPeriod == copied) {
    return
}

Repository repo = Kernel.get(Repository.class)
repo.runAsSystem({ Session session ->
    doc.recurring_copies = (copied + 1).toString()

    def formNo = doc.formNo

    def indexes = doc.metadata().all
    indexes.remove('formNo')
    indexes.remove('workflow_id')
    indexes.remove('workflow_status')

    DocumentModel copy = doc.copyTo("Sanlam Glacier/Finance/Payment Authorisation/New Payment Requests", new DocumentDTO(filename: 'copy.pdf', indexes: indexes))

    copy.ownership().assign(doc.ownership().owner)

    doc.session.query("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents' WHERE recursive = true AND formNo = '${formNo}'").each { DocumentModel supporting ->

        copyDocument(supporting, copy)
    }

    doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Tables' WHERE formNo = '${formNo}'").each { DocumentModel costCentre ->
        copyDocument(costCentre, copy)

        doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Table Rows' WHERE formNo = '${formNo}' " +
                "AND co_code = '${costCentre.co_code}' AND Cost_Centre = '${costCentre.Cost_Centre}'").each { DocumentModel costRow ->

            copyDocument(costRow, copy)
        }
    }

    copy.allocate("Payment Authorisation")

} as Handler<Session>)

DocumentModel copyDocument(DocumentModel original, DocumentModel application) {
    def indexes = original.metadata().all
    indexes.remove('approved_by')
    indexes.remove('approved_date')
    indexes.remove('workflow_id')
    indexes.remove('workflow_status')

    indexes.formNo = application.formNo

    original.copyTo(original.node.fullPath, new DocumentDTO(filename: original.filename, indexes: indexes))
}