import com.egis.DocumentModel
import com.egis.utils.Is

DocumentModel doc = doc

doc.approved_by = doc.session.user.name

doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Table Rows' WHERE formNo = '${doc.formNo}'" +
        " AND invoice_number = '${doc.invoice_number}'").each { DocumentModel row ->

    row.approve = doc.approve
}