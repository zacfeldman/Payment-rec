import com.egis.DocumentModel
import com.egis.Repository
import com.egis.Session
import com.egis.kernel.Kernel
import com.egis.utils.Is

import java.text.DecimalFormat
import java.text.NumberFormat

DocumentModel doc = doc

DocumentModel paymentAuth = doc.session.getDocument("SELECT * FROM 'Sanlam Glacier/Finance/Payment Authorisation' WHERE recursive = true AND formNo = '${doc.formNo}'")

if (Is.empty(paymentAuth)) {
    return
}

Repository repo = Kernel.get(Repository.class)

repo.callAsSystem({ Session session ->
    session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Table Rows' WHERE formNo = '${doc.formNo}' " +
            "AND co_code = '${doc.co_code}' AND Cost_Centre = '${doc.Cost_Centre}'").each {

        it.delete()
    }
})

NumberFormat formatter = new DecimalFormat("###,###,##0.00")

paymentAuth.grand_debit_total = formatter.format(getDecimalValue(paymentAuth.grand_debit_total) - getDecimalValue(doc.debit_total))

BigDecimal getDecimalValue(String value) {

    if (Is.empty(value)) {
        return 0
    }

    return new BigDecimal(value.replaceAll(',', ''))
}