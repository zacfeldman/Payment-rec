import com.egis.DocumentModel

DocumentModel doc = doc

doc.session.query("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents/Supplier Invoice' WHERE formNo = '${doc.formNo}'").each {
    it.workflow().end()
}
