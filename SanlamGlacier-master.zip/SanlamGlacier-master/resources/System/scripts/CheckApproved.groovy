import com.egis.DocumentModel

DocumentModel doc = doc

doc.parties().remove(doc.session.user)

def allApproved = true

doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Tables' " +
        "WHERE formNo = '${doc.formNo}'").each { DocumentModel costCentre ->

    if(!'true'.equalsIgnoreCase(costCentre.cost_centre_head_approved)) {
        allApproved = false
    }
}

doc.all_approved = allApproved.toString()