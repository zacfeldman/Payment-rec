import com.egis.DocumentModel

DocumentModel doc = doc

doc.session.query("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents/Supplier Invoice' WHERE formNo = '${doc.formNo}'").each {
    it.approvers = "${doc.signature1},${doc.signature2}".toString()
    it.batch_no = doc.batch_no
    it.allocate("Invoice Workflow")
}