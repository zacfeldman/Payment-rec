import com.egis.DocumentModel
import com.egis.Repository
import com.egis.Session
import com.egis.kernel.Kernel
import com.egis.utils.Is

DocumentModel doc = doc

Repository repo = Kernel.get(Repository.class)

repo.callAsSystem({ Session session ->
    if (!Is.empty(doc.batch_no)) {
        doc.moveTo(session.createOrGetNode('Sanlam Glacier/Finance/Payment Authorisation/Complete' + '/' + doc.batch_no))
    }
})