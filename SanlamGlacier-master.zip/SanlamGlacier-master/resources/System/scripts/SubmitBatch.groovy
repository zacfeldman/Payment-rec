import com.egis.DocumentModel

DocumentModel doc = doc

DocumentModel batch = doc.session.createItem('Sanlam Glacier/Finance/Supporting Documents/Batch Payments', 'Batch Payment')

doc.batch_no = batch.batch_no