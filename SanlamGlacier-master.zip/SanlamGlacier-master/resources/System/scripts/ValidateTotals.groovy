import com.egis.DocumentModel
import com.egis.utils.Is
import com.egis.utils.ValidationException

DocumentModel doc = doc

if(getDecimalValue(doc.creditor_total) != getDecimalValue(doc.grand_debit_total)) {
    throw new ValidationException("Credit Total: ${doc.creditor_total} must equal Debit Total: ${doc.grand_debit_total}");
}

BigDecimal getDecimalValue(String value) {

    if(Is.empty(value)) {
        return 0
    }

    return new BigDecimal(value.replaceAll(',', ''))
}