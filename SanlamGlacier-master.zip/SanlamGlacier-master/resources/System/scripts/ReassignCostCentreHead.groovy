import com.egis.AllocationOptions
import com.egis.DocumentModel
import com.egis.utils.Is

DocumentModel doc = doc
DocumentModel paymentAuth = doc.session.getDocument("SELECT * FROM 'Sanlam Glacier/Finance/Payment Authorisation' WHERE recursive = true AND formNo = '${doc.formNo}'")

if (Is.empty(paymentAuth)) {
    return
}

paymentAuth.parties().add(doc.approver, new AllocationOptions(instruction: "Please review and approve Supplier Invoice"))