import com.egis.DocumentModel
import com.egis.utils.FileUtils
import com.egis.utils.Is
import com.egis.utils.Utils
import com.egis.utils.report.PdfReport
import com.egis.utils.report.Text
import com.lowagie.text.pdf.BaseFont

import java.awt.Color

DocumentModel doc = doc

Text font = new Text().fontSize(9).align('left').color(Utils.colorFromString('#808080'))
Text label = new Text().fontSize(9).align('left').bold(true).color(Utils.colorFromString('#90A0C0'))
Text table = new Text().fontSize(9).align('left').color(Utils.colorFromString('#808080')).border(PdfReport.BOTTOM)
Text header = new Text().fontSize(9).align('left').color(Utils.colorFromString('#90A0C0')).border(PdfReport.BOTTOM).bold(true)
PdfReport report = new PdfReport()

report.setFont(BaseFont.HELVETICA)
report.cellPadding = 2
report.setHeader(font.clone().fontSize(9).backgroundColor(Color.WHITE).border(PdfReport.TOP))
report.setMargins(15, 15, 100, 15)
report.setCellPadding(4)
report.setBorderWidth(0.8)
report.setTableWidth(100)
report.open()

report.addImage(doc.session.getDocument('System/images/glacier_logo.jpg').content().read(), 15, 775, 170, 53)

report.addText(font.clone("Payment Request Authorisation ").bold(true).fontSize(13).align('center').color(Utils.colorFromString('#5270A2')))

report.addTableHeader(font.clone('Creditor Details:').bold(true).fontSize(10).color(Utils.colorFromString('#5270A2')))
report.addHeader('', 25)
report.addHeader('', 25)
report.addHeader('', 25)
report.addHeader('', 25)

report.setBorderColor(Color.WHITE)

report.addRow(label.clone("Vendor Name:"), font.clone(doc.vendor_name), label.clone("Amount:"), font.clone(doc.amount))
report.addRow(label.clone("Reason for Expenses:"), font.clone(doc.reason_for_expense), label.clone("Recurring Payment:"), font.clone(doc.recurring_payment == 'true' ? 'Yes' : 'No'))
report.flush()

report.addTableHeader(font.clone('Banking Details:').bold(true).fontSize(10).color(Utils.colorFromString('#5270A2')))
report.addHeader('', 25)
report.addHeader('', 25)
report.addHeader('', 25)
report.addHeader('', 25)

report.setBorderColor(Color.WHITE)

report.addRow(label.clone("Bank:"), font.clone(doc.bank), label.clone("Deposit Reference:"), font.clone(doc.deposit_reference))
report.addRow(label.clone("Branch:"), font.clone(doc.branch), label.clone("Account Number:"), font.clone(doc.bank_account_number))
report.addRow(label.clone("Bank Account Type:"), font.clone(doc.bank_account_type), label.clone(""), font.clone(""))
report.flush()

report.addTableHeader(font.clone('Creditor/Vendor:').bold(true).fontSize(10).color(Utils.colorFromString('#5270A2')))
report.addHeader('', 10)
report.addHeader('', 10)
report.addHeader('', 10)
report.addHeader('', 10)
report.addHeader('', 10)
report.addHeader('', 10)
report.addHeader('', 10)
report.addHeader('', 10)

report.setBorderColor(Utils.colorFromString('#5270A2'))

report.addRow(header.clone("Name"),
        header.clone("Invoice Number"),
        header.clone("Co Code"),
        header.clone("Amount"),
        header.clone("Account"),
        header.clone("Provision"),
        header.clone("SAP Document Number"),
        header.clone("Document Type"))

doc.session.query("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents/Supplier Invoice' WHERE formNo = '${doc.formNo}'").each {

    report.addRow(table.clone(it.filename),
            table.clone(it.invoice_number),
            table.clone(it.co_code),
            table.clone(it.amount),
            table.clone(it.account),
            table.clone(it.provision == 'true' ? 'Yes' : 'No'),
            table.clone(it.sap_doc_number),
            table.clone(it.document_type))
}

report.flush()

report.addHeader('', 25)
report.addHeader('', 25)
report.addHeader('', 25)
report.addHeader('', 25)

report.setBorderColor(Color.WHITE)

report.addRow(label.clone("Posted SAP Entry").color(Utils.colorFromString('#5270A2')), font.clone(""),
        label.clone("Proof of Payment").color(Utils.colorFromString('#5270A2')), font.clone(""))

def sapEntry = doc.session.getDocument("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents/Posted SAP Entry' WHERE formNo = '${doc.formNo}'")
def proofOfPayment = doc.session.getDocument("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents/Proof of Payment' WHERE formNo = '${doc.formNo}'")

report.addRow(header.clone("Payment Ref No:"), table.clone(sapEntry ? sapEntry.payment_reference_number : ''),
        header.clone("Payment Ref No:"), table.clone(proofOfPayment ? proofOfPayment.payment_reference_number : ''))

report.addRow(header.clone("Posted By:"), table.clone(sapEntry ? sapEntry.posted_by : ''),
        font.clone(""), font.clone(""))

report.addRow(header.clone("Vendor Code:"), table.clone(sapEntry ? sapEntry.vendor_code : ''),
        font.clone(""), font.clone(""))

report.addRow(header.clone("Vendor Name:"), table.clone(sapEntry ? sapEntry.vendor_name : ''),
        font.clone(""), font.clone(""))

report.addRow(header.clone("Cross Company Doc No:"), table.clone(sapEntry ? sapEntry.cross_company_doc_no : ''),
        font.clone(""), font.clone(""))


report.flush()

doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Tables' WHERE formNo = '${doc.formNo}' ").each { DocumentModel costCentre ->

    report.addTableHeader(font.clone('Debit/Expense Details:').bold(true).fontSize(10).color(Utils.colorFromString('#5270A2')))
    report.addHeader('', 25)
    report.addHeader('', 25)
    report.addHeader('', 25)
    report.addHeader('', 25)

    report.setBorderColor(Color.WHITE)

    report.addRow(label.clone("Co Code:"), font.clone(costCentre.co_code), label.clone("Authorised By:"), font.clone(costCentre.approved_by))
    report.addRow(label.clone("Cost Centre:"), font.clone(costCentre.Cost_Centre), label.clone("Authorised Date:"), font.clone(costCentre.approved_date))
    report.flush()

    report.addHeader('', 10)
    report.addHeader('', 10)
    report.addHeader('', 10)
    report.addHeader('', 10)
    report.addHeader('', 10)
    report.addHeader('', 10)
    report.addHeader('', 10)
    report.addHeader('', 10)
    report.addHeader('', 10)

    report.setBorderColor(Utils.colorFromString('#5270A2'))

    report.addRow(header.clone("Prepaid"),
            header.clone("Post Key"),
            header.clone("Account"),
            header.clone("Amount"),
            header.clone("Invoice Number"),
            header.clone("BA"),
            header.clone("Profit Centre"),
            header.clone("Approve"),
            header.clone("Tax"))

    doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Table Rows' WHERE formNo = '${doc.formNo}' " +
            "AND co_code = '${costCentre.co_code}' AND Cost_Centre = '${costCentre.Cost_Centre}'").each { DocumentModel row ->

        report.addRow(table.clone(row.prepaid == 'true' ? 'Yes' : 'No'),
                table.clone(row.post_key),
                table.clone(row.account),
                table.clone(row.amount),
                table.clone(row.invoice_number),
                table.clone(row.BA),
                table.clone(row.profit_centre),
                table.clone(row.approve),
                table.clone(row.tax))
    }
}



doc.content().update(FileUtils.open(report.create()), '')
