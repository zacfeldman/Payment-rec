import com.egis.DocumentModel
import com.egis.utils.ValidationException

DocumentModel doc = doc

def sapEntry = doc.session.query("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents/Posted SAP Entry' WHERE formNo = '${doc.formNo}'")

if (sapEntry.size() < 1) {
    throw new ValidationException("No Posted SAP Entry Document Uploaded")
}