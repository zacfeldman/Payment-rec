import com.egis.DocumentModel

import java.text.DecimalFormat
import java.text.NumberFormat

DocumentModel doc = doc

BigDecimal total = 0
NumberFormat formatter = new DecimalFormat("###,###,##0.00")

doc.session.query("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents/Supplier Invoice' WHERE recursive = true AND formNo = '${doc.formNo}'").each { DocumentModel invoice ->
    if (!'blocked'.equalsIgnoreCase(invoice.approve)) {
        total += new BigDecimal(invoice.amount.toString())
    }
}

doc.creditor_total = formatter.format(total)

BigDecimal grandTotal = 0


doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Tables' WHERE formNo = '${doc.formNo}'").each { DocumentModel costCentre ->
    total = 0

    doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Table Rows' WHERE formNo = '${doc.formNo}' " +
            "AND co_code = '${costCentre.co_code}' AND Cost_Centre = '${costCentre.Cost_Centre}'").each { DocumentModel costRow ->

        if (!'blocked'.equalsIgnoreCase(costRow.approve)) {
            total += new BigDecimal(costRow.amount.toString())
        }
    }

    grandTotal += total

    costCentre.setEventsEnabled(false)
    costCentre.debit_total = formatter.format(total)
    costCentre.save()
    costCentre.setEventsEnabled(true)
}

doc.grand_debit_total = formatter.format(grandTotal)