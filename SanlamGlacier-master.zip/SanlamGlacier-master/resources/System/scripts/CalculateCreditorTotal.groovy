import com.egis.DocumentModel
import com.egis.utils.Is
import com.egis.utils.ValidationUtils

import java.text.DecimalFormat
import java.text.NumberFormat

DocumentModel doc = doc

DocumentModel paymentAuth = doc.session.getDocument("SELECT * FROM 'Sanlam Glacier/Finance/Payment Authorisation' WHERE recursive = true AND formNo = '${doc.formNo}'")

if (Is.empty(paymentAuth)) {
    return
}

BigDecimal total = 0

doc.session.query("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents/Supplier Invoice' WHERE formNo = '${doc.formNo}'").each {

    if (!Is.empty(it.amount) && doc.docId != it.docId && !'blocked'.equalsIgnoreCase(it.approve)) {
        total += new BigDecimal(it.amount.toString())
    }
}

if (!Is.empty(doc.amount) && !'blocked'.equalsIgnoreCase(doc.approve)) {
    total += new BigDecimal(doc.amount.toString())
}

NumberFormat formatter = new DecimalFormat("###,###,##0.00")
paymentAuth.creditor_total = formatter.format(total)