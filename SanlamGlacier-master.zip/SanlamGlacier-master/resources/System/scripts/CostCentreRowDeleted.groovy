import com.egis.DocumentModel
import com.egis.utils.Is

import java.text.DecimalFormat
import java.text.NumberFormat

DocumentModel doc = doc

DocumentModel paymentAuth = doc.session.getDocument("SELECT * FROM 'Sanlam Glacier/Finance/Payment Authorisation' WHERE recursive = true AND formNo = '${doc.formNo}'")

if (Is.empty(paymentAuth)) {
    return
}

BigDecimal grandTotal = 0
BigDecimal total = 0
NumberFormat formatter = new DecimalFormat("###,###,##0.00")

doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Tables' WHERE formNo = '${doc.formNo}'").each { DocumentModel costCentre ->
    total = 0

    doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Table Rows' WHERE formNo = '${doc.formNo}' " +
            "AND co_code = '${costCentre.co_code}' AND Cost_Centre = '${costCentre.Cost_Centre}'").each { DocumentModel costRow ->


        if (!Is.empty(costRow.amount) && doc.docId != costRow.docId && !'blocked'.equalsIgnoreCase(costRow.approve)) {
            total += new BigDecimal(costRow.amount.toString())
        }
    }

    grandTotal += total

    costCentre.setEventsEnabled(false)
    costCentre.debit_total = formatter.format(total)
    costCentre.save()
    costCentre.setEventsEnabled(true)
}

paymentAuth.grand_debit_total = formatter.format(grandTotal)

BigDecimal getDecimalValue(String value) {

    if (Is.empty(value)) {
        return 0
    }

    return new BigDecimal(value.replaceAll(',', ''))
}