
import com.egis.DocumentModel
import com.egis.utils.ValidationException

DocumentModel doc = doc

def pop = doc.session.query("SELECT * FROM 'Sanlam Glacier/Finance/Supporting Documents/Proof of Payment' WHERE formNo = '${doc.formNo}'")

if (pop.size() < 1) {
    throw new ValidationException("No Proof of Payment Document Uploaded")
}