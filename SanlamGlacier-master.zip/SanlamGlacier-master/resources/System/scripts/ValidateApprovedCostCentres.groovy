import com.egis.DocumentModel
import com.egis.utils.ValidationException

DocumentModel doc = doc

def allApproved = true
doc.session.query("SELECT * FROM 'Sanlam Glacier/Debit Cost Centre Tables/Tables' " +
        "WHERE formNo = '${doc.formNo}' AND approver = '${doc.session.user.name}'").each { DocumentModel costCentre ->

    if (costCentre.cost_centre_head_approved != 'true') {
        allApproved = false
    }
}

if(!allApproved) {
    throw new ValidationException("You have not Approved all of your Cost Centre Tables")
}