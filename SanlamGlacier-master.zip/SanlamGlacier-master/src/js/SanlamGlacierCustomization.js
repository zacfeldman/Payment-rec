import DocViewSetup from './views/DocViewSetup';
import NewPaymentRequest from './action/NewPaymentRequest'
import {BATCH_PAYMENTS, PAYMENT_AUTH} from './SharedConstants';
import BatchViewSetup from "./views/BatchViewSetup";

export default class SanlamGlacierCustomization {
    init() {
        this.initViews();
        this.initMenu();
        return this;
    }

    beforeReassign(options) {
        options.target.approver = options.doc.indexes.approver;
    }

    initViews() {
        new DocViewSetup().init();
        new BatchViewSetup().init();
    }

    queryUrl(root, filter, fieldsModifier) {
        fieldsModifier = fieldsModifier || (a => a);
        let fields = fieldsModifier([
            'filename',
            'createdDate',
            'formNo',
            'expense_capturer',
            'vendor_code',
            'contract_period',
            'payment_terms',
            'bank',
            'Branch',
            'vendor_name',
            'currentUsers'
        ]);

        let query = '';
        if (!is.empty(filter)) {
            query = 'WHERE ' + filter;
        }

        return `#node/${PAYMENT_AUTH}/${root}?filter=` +
            encodeURIComponent(`SELECT ${fields.join(',')} from '${PAYMENT_AUTH}/${root}'` + query)
    }

    initMenu() {
        UI.properties.disableEsignList = true;
        UI.properties.disableQueues = true;

        let sanlam = UI.sidebar.addMenu('Payment Authorisations', 'business-check');
        sanlam.add('Create Payment Requests', NewPaymentRequest);
        sanlam.add('New Payment Requests', this.queryUrl('New Payment Requests', `filename != ''`));
        sanlam.add('Pending Batch Payment', this.queryUrl('Pending Batch Payment', `filename != ''`));
        sanlam.add('Pending Payment', this.queryUrl('Pending Payment', `filename != ''`));
        sanlam.add('Prepaid', this.queryUrl('Prepaid', `filename != ''`));
        sanlam.add('Provision', this.queryUrl('Provision', `filename != ''`));
        sanlam.add('Completed', this.queryUrl('Complete', `filename != ''`));
        sanlam.add('Discarded', this.queryUrl('Discard', `filename != ''`));
        sanlam.add('Batch Payments', `#node/${BATCH_PAYMENTS}`)
    }
}