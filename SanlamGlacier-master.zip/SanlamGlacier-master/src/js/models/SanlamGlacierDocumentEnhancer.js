import {PAYMENT_AUTH, BATCH_PAYMENTS} from '../SharedConstants';

export default class SanlamGlacierDocumentEnhancer {

    static isSuitableDoc(doc) {
        console.log('isSuitableDoc', doc.node.contains(PAYMENT_AUTH));
        return (doc.node.contains(PAYMENT_AUTH));
    }

    static isBatchDoc(doc) {
        console.log('isBatchDoc', doc.node.contains(BATCH_PAYMENTS));
        return (doc.node.contains(BATCH_PAYMENTS));
    }
}