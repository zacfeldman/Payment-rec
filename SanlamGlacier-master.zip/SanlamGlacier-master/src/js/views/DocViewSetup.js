import SanlamGlacierDocumentEnhancer from '../models/SanlamGlacierDocumentEnhancer';
import BankBatchList from '../views/BankBatchList';
import exportTransactions from '../action/ExportTransactions';
import {BATCH_PAYMENTS, PAYMENT_AUTH} from '../SharedConstants'

const SplitPreview = EgisUI.SplitPreview;

export default class DocViewSetup {

    constructor() {
        this.docFilter = SanlamGlacierDocumentEnhancer.isSuitableDoc;
    }

    init() {
        let me = this;
        let NODES = {
            SUPPLIER_INVOICES: 'Sanlam Glacier/Finance/Supporting Documents/Supplier Invoice',
            COST_CENTRE_ITEMS: 'Sanlam Glacier/Debit Cost Centre Tables/Table Rows',
            COST_CENTRE_TABLES: 'Sanlam Glacier/Debit Cost Centre Tables/Tables',
            SAP_ENTRY: 'Sanlam Glacier/Finance/Supporting Documents/Posted SAP Entry',
            PROOF_OF_PAYMENT: 'Sanlam Glacier/Finance/Supporting Documents/Proof of Payment'
        };

        PaperTrail.addDocumentFilter(doc => {
            doc.NODES = NODES;
            doc.PQLS = me.setupPQLs(doc);
            if (this.docFilter(doc)) {
                app.view.splitPreview = new SplitPreview(app.view, {minMain: 563});
            }
            return doc;
        });

        UI.addTemplate({
            filter: this.docFilter,
            template: 'Payments',
            activeTab: 'PaymentAuth'
        });

        this.initHelpers();
        this.initTabs();
        this.initActions();
        this.initRouter();
        this.initClicks();
    }

    initActions() {
        Actions.registerLocal('submit_bank_batch', {
            action: (docs, docIds, source) => {
                new ActionDialog({
                    doc: docIds,
                    source: source,
                    title: 'Bulk Approve/Submit',
                    submitTitle: 'Submit',
                    action_name: 'edit_indexes',
                    fields: [
                        {
                            type: 'combo',
                            url: '/data/Signatories?group=First Signatories&filter=',
                            name: 'indexes.signature1',
                            label: 'Signatory 1',
                            required: true
                        },
                        {
                            type: 'combo',
                            url: '/data/Signatories?group=Second Signatories&filter=',
                            name: 'indexes.signature2',
                            label: 'Signatory 2',
                            required: true
                        }
                    ]
                }).show()
                    .then(() => {

                        HTTP.post('/action/execute/create_document', {
                            'node': BATCH_PAYMENTS,
                            'template': 'Item (no file)',
                            'index.filename': 'Batch Payment'
                        }).then((item) => {
                            Promise.all(docs.map(doc => {
                                log.info("Submitting Bank Batch", doc.docId);

                                let vals = {};
                                HTTP.post('/action/execute/complete_task', Object.assign({docId: doc.docId}, vals));

                                vals = {'indexes.batch_no': item.indexes.batch_no};

                                HTTP.post('/action/execute/edit_indexes', Object.assign({docId: doc.docId}, vals));
                            }))
                                .then(() => {
                                    Msg.notify('All Selected Authorisations have been Submitted');
                                    setTimeout(() => {
                                        app.view.refresh();
                                    }, 1000);
                                });
                        });
                    });
            },
            canExecute: () => {
                if (!app.view || app.view.doc) {
                    return false;
                }
                return true;
            }
        });

        Actions.registerLocal('create_direct', {
            action: function (doc, vals, source) {
                PaperTrail.uploadTo(vals.node, _.hash_filter(vals, (v, k) => k.startsWith("index.")), _.data(source))
                    .then((doc) => {
                        setTimeout(function () {
                            app.view.refresh()
                        }, 1000);
                    });
            },
            canExecute: (node) => {
                return true;
            }
        });
    }

    initHelpers() {
        Handlebars.registerHelper('role_in', function (arg1, arg2, options) {

            if (is.empty(arg1)) {
                return options.inverse(this);
            }

            return (arg2.contains(arg1) && app.doc.currentUsers.contains(UI.user.name)) ? options.fn(this) : options.inverse(this);
        });

        Handlebars.registerHelper('not_signatory', function (status, options) {

            if (is.empty(status)) {
                return options.inverse(this);
            }

            return (!status.contains("Signatory")) ? options.fn(this) : options.inverse(this);
        });

        Handlebars.registerHelper('not_approved', function (doc, options) {
            return (doc.cost_centre_head_approved !== 'true') ? options.fn(this) : options.inverse(this);
        });

        Handlebars.registerHelper('is_approver', function (doc, options) {
            return (doc.approver === UI.user.name && app.doc.currentUsers.contains(UI.user.name)) ? options.fn(this) : options.inverse(this);
        });

        Handlebars.registerHelper('is_creator', function (doc, options) {
            return (doc.createdBy === UI.user.name && app.doc.currentUsers.contains(UI.user.name)) ? options.fn(this) : options.inverse(this);
        });

        Handlebars.registerHelper('is_current_user', function (options) {
            return (app.doc.currentUsers.contains(UI.user.name)) ? options.fn(this) : options.inverse(this);
        });
    }

    initRouter() {
        let batchPayment = '#node/Sanlam Glacier/Finance/Payment Authorisation/Pending Batch Payment';
        router.registerRouter(batchPayment, new BankBatchList());
    }

    setupPQLs(doc) {
        let formNo = doc.indexes.formNo;
        let batch_no = doc.indexes.batch_no;

        return {
            transactions: `SELECT invoice_number,provision,document_type,co_code,Cost_Centre,account,Amount,sap_doc_number,batch_no,bank,branch,bank_account_number,bank_account_type,vendor_name,vendor_code,signature1,signature2,approve,total_approved,total_blocked,date_invoices_approved FROM '${doc.NODES.SUPPLIER_INVOICES}' WHERE formNo = '${formNo}'`,
            supplier_invoice: `SELECT invoice_number,provision,approve,approved_by,co_code,account,Amount,sap_doc_number FROM '${doc.NODES.SUPPLIER_INVOICES}' WHERE formNo = '${formNo}'`,
            transaction: `SELECT co_code,post_key,account,Amount,invoice_number,tax,BA,profit_centre FROM '${doc.NODES.COST_CENTRE_ITEMS}' WHERE formNo = '${formNo}'`,
            posted_sap_entry: `SELECT payment_reference_number,cross_company_doc_no,vendor_name,vendor_code,posted_by,document_type FROM '${doc.NODES.SAP_ENTRY}' WHERE formNo = '${formNo}'`,
            proof_of_payment: `SELECT payment_reference_number FROM '${doc.NODES.PROOF_OF_PAYMENT}' WHERE formNo = '${formNo}'`,
            batch_transactions: `SELECT invoice_number,provision,document_type,co_code,account,Amount,sap_doc_number,batch_no,bank,branch,bank_account_number,bank_account_type,vendor_name,signature1,signature2,approve,total_approved,total_blocked,date_invoices_approved FROM '${doc.NODES.SUPPLIER_INVOICES}' WHERE batch_no = '${batch_no}' AND approve != 'Blocked'`,
            batch_supplier_invoice: `SELECT invoice_number,provision,document_type,co_code,account,Amount,sap_doc_number FROM '${doc.NODES.SUPPLIER_INVOICES}' WHERE batch_no = '${batch_no}' AND approve != 'Blocked'`,
            batch_payment_reqs: `SELECT filename,createdDate,formNo,expense_capturer,vendor_code,contract_period,payment_terms,bank,Branch,vendor_name,currentUsers FROM '${PAYMENT_AUTH}' WHERE batch_no = '${batch_no}'`
        };
    }

    initClicks() {
        $(document.body).on('click', 'a.export', (a) => {
            exportTransactions();
        });
    }

    initTabs() {
        UI.addTab({
            title: 'Payment Auth',
            template: 'PaymentAuth.hbs',
            filter: this.docFilter,
            load: doc => Promise.resolve(doc)
        });

        UI.addTab({
            title: 'Debit/Expense Cost Centre',
            template: 'CostCentre.hbs',
            filter: this.docFilter,
            load: function (doc) {
                return PaperTrail.pql(`SELECT * FROM '${doc.NODES.COST_CENTRE_TABLES}' WHERE formNo = '${doc.indexes.formNo}'`).then(results => {
                    doc.cost_centre_tables = results;
                })
            }
        });

        UI.addTab({
            title: 'Transactions',
            template: 'Transactions.hbs',
            filter: this.docFilter,
            load: doc => Promise.resolve(doc)
        });


        UI.addTab({
            title: 'Notes',
            template: 'Notes.hbs',
            filter: this.docFilter,
            load: doc => doc.getNotes()
        });

        UI.addTab({
            title: 'Linked Forms',
            template: 'LinkedForms.hbs',
            filter: this.docFilter,
            load: doc => Promise.resolve(doc)
        });

        UI.addTab({
            title: 'History',
            template: 'History.hbs',
            filter: this.docFilter,
            load: doc => doc.loadMetadata('history')
        });
    }
}