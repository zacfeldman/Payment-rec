const CERTIFICATE_FIELDS = [
    'filename', 'createdDate', 'vendor_name', 'vendor_code', 'payment_terms', 'formNo', 'expense_capturer', 'deposit_reference',
    'contract_period', 'bank_account_type', 'bank_account_number', 'bank', 'Branch', 'Amount', 'workflow_status'
];

const BANK_BATCH_NODE = 'Sanlam Glacier/Finance/Payment Authorisation/Pending Batch Payment';

export default class BankBatchList extends DocumentListView {

    constructor() {
        super({
            list: new DocumentList({
                columns: CERTIFICATE_FIELDS
            }),
            template: 'BankBatchList',
            documentView: router.doc
        });
    }

    route(params) {
        params.node = BANK_BATCH_NODE;

        let filter = `SELECT '` + CERTIFICATE_FIELDS + `' from '${params.node}'`;

        params.filter = filter;

        this.search(params.query, params);
    }
}