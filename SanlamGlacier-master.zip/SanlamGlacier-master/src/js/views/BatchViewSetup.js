import SanlamGlacierDocumentEnhancer from '../models/SanlamGlacierDocumentEnhancer';
import exportBatchTransactions from '../action/ExportBatchTransactions';

const SplitPreview = EgisUI.SplitPreview;

export default class BatchViewSetup {

    constructor() {
        this.docFilter = SanlamGlacierDocumentEnhancer.isBatchDoc;
    }

    init() {
        PaperTrail.addDocumentFilter(doc => {
            if (this.docFilter(doc)) {
                app.view.splitPreview = new SplitPreview(app.view);
            }

            return doc;
        });

        UI.addTemplate({
            filter: this.docFilter,
            template: 'BatchPayments',
            activeTab: 'PaymentRequisitions'
        });

        this.initTabs();
        this.initClicks();
    }

    initClicks() {
        $(document.body).on('click', 'b.export', (a) => {
            exportBatchTransactions();
        });
    }

    initTabs() {
        UI.addTab({
            title: 'PaymentRequisitions',
            template: 'PaymentRequisitions.hbs',
            filter: this.docFilter,
            load: doc => Promise.resolve(doc)
        });

        UI.addTab({
            title: 'Transactions',
            template: 'BatchTransactions.hbs',
            filter: this.docFilter,
            load: doc => Promise.resolve(doc)
        });
    }
}