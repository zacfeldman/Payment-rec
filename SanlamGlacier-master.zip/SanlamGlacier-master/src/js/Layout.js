import SanlamGlacierCustomization from './SanlamGlacierCustomization';

UI.plugin(() => {
    console.log('Loading plugin Sanlam v0.2.3');

    window.SanlamGlacierCustomization = new SanlamGlacierCustomization().init();
});
