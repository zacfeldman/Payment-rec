export const ROOT_NODE = 'Sanlam Glacier';
export const FINANCE = ROOT_NODE + '/Finance';
export const PAYMENT_AUTH = FINANCE + '/Payment Authorisation';
export const NEW_PAYMENT_AUTH = PAYMENT_AUTH + '/New Payment Requests';
export const BATCH_PAYMENTS = 'Sanlam Glacier/Finance/Supporting Documents/Batch Payments';