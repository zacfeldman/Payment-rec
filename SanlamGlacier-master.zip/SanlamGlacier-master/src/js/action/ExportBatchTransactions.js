export default function exportBatchTransactions() {

    HTTP.get('/document/pql', {
        query: app.doc.PQLS.batch_transactions,
        sort: '',
        dir: '',
        format: 'csv'
    }).then((response) => {
        let url = response.url;

        if (!is.empty(app.doc.indexes.batch_no)) {
            url = url.replace('export.csv', app.doc.indexes.batch_no + '_export.csv')
        }
        download(url)
    });
}