import {NEW_PAYMENT_AUTH} from '../SharedConstants';

export default function createNewPaymentRequest() {

    new ActionDialog({
        action_name: 'create_document',
        title: 'Create New Payment Request',
        fields: [
            {
                type: 'hidden',
                value: NEW_PAYMENT_AUTH,
                name: 'node'
            },
            {
                type: 'hidden',
                name: 'template',
                value: 'Glacier'
            },
            {
                type: 'combo',
                name: 'index.payment_terms',
                data: ['Immediate Payment - Electronic', 'Normal Payment Terms'],
                label: 'Payment Terms',
                required: true
            }
        ]
    }).show()
        .then(doc => {
            setTimeout(() => {
                window.router.routeTo('document/' + doc.docId + '/view')
            }, 1000);
        })
}